<img style="display: flex; justify-content: center;" src="model.png">
# About The Repository
This repository contains previous versions of Simple Vehicles Add-On which also includes several versions and efforts I did and it was Started in Year 2019 Named as Aspire Vehicles Which is based from the laptop series that I started using to develop this add-on.

# Why This was be Open For Now?
I decide to release the old source code of this Add-On so that anyone can try, see, modify and do whatever they want too 

# Is the Latest One is Available Soon to be Open-Source?
I guess not for now But the Aspire Vehicles and Simple Vehicles Add-on 1 and 2 will be Open Under GPL License but the Version 3 is stayed proprietary 

# To make this clear Simple Vehicles Add-on has several versions as of today and this was based on the Final Builds previously
 - Simple Vehicles Add-on v1: GPL V3
 - Simple Vehicles Add-on v1.7.2-Final: GPL V3
 - Simple Vehicles Add-on v2: --TBA--
 - Simple Vehicles Add-on v3: Proprietary

Tools used for developing such as 
- Blockbench
- VSCode or VSCodium (For Version 1 and Version 2)
- Regolith compiler for development (Faster than bridge v2)
- Bridge V2 (For Version 3)